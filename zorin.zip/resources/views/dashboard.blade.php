<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Zorin Rice Milling')</title>
   <!-- ✅ CORRECT - Vite directive -->
@vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="antialiased">
    <script>
        const t = localStorage.getItem('zorin-theme') || 'forest';
        document.documentElement.setAttribute('data-theme', t);
    </script>

    <div class="min-h-screen flex bg-gray-50">
        {{-- SIDEBAR --}}
        <aside class="w-64 bg-white border-r border-gray-200 flex-shrink-0">
            <div class="px-6 py-8 border-b border-gray-200">
                <div class="flex items-center space-x-4">
                    <div class="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center">
                        <i class="fas fa-seedling text-white"></i>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold text-gray-900">Zorin</h1>
                        <p class="text-sm text-gray-500">Rice Milling System</p>
                    </div>
                </div>
            </div>

            <nav class="mt-6 space-y-2 px-6">
                <div class="px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider">Main</div>
                <a href="{{ route('dashboard') }}" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg @if(request()->is('dashboard')) bg-green-50 text-green-800 @else hover:bg-gray-50 @endif">
                    <i class="fas fa-home mr-3"></i>
                    <span>Dashboard</span>
                </a>
                <a href="{{ route('farmers.index') }}" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg @if(request()->is('farmers*')) bg-green-50 text-green-800 @else hover:bg-gray-50 @endif">
                    <i class="fas fa-user-tie mr-3"></i>
                    <span>Farmers</span>
                </a>

                <div class="mt-6 px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider">Operations</div>
                <a href="{{ route('paddy-purchases.index') }}" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg @if(request()->is('paddy-purchases*')) bg-green-50 text-green-800 @else hover:bg-gray-50 @endif">
                    <i class="fas fa-shopping-cart mr-3"></i>
                    <span>Paddy Purchases</span>
                </a>
                <a href="{{ route('milling-batches.index') }}" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg @if(request()->is('milling-batches*')) bg-green-50 text-green-800 @else hover:bg-gray-50 @endif">
                    <i class="fas fa-seedling mr-3"></i>
                    <span>Milling Batches</span>
                </a>
                <a href="{{ route('inventory.index') }}" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg @if(request()->is('inventory*')) bg-green-50 text-green-800 @else hover:bg-gray-50 @endif">
                    <i class="fas fa-boxes mr-3"></i>
                    <span>Inventory</span>
                </a>
                <a href="{{ route('sales.index') }}" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg @if(request()->is('sales*')) bg-green-50 text-green-800 @else hover:bg-gray-50 @endif">
                    <i class="fas fa-dollar-sign mr-3"></i>
                    <span>Sales</span>
                </a>

                <div class="mt-6 px-3 py-2 text-xs font-medium text-gray-500 uppercase tracking-wider">Finance</div>
                <a href="{{ route('reports.index') }}" class="flex items-center px-4 py-3 text-sm font-medium rounded-lg @if(request()->is('reports*')) bg-green-50 text-green-800 @else hover:bg-gray-50 @endif">
                    <i class="fas fa-chart-bar mr-3"></i>
                    <span>Reports</span>
                </a>

                <div class="mt-auto px-6 py-6 border-t border-gray-200">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
                            <i class="fas fa-user-circle text-green-600"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-900">{{ Auth::user()->name }}</p>
                            <p class="text-sm text-gray-500">{{ Auth::user()->email }}</p>
                        </div>
                    </div>
                    <form method="POST" action="{{ route('logout') }}" class="mt-4 w-full">
                        @csrf
                        <button type="submit" class="w-full flex items-center px-4 py-3 text-sm font-medium text-gray-600 rounded-lg hover:bg-gray-50 transition-colors">
                            <i class="fas fa-sign-out-alt mr-3"></i>
                            <span>Sign Out</span>
                        </button>
                    </form>
                </div>
            </nav>
        </aside>

        {{-- MAIN CONTENT --}}
        <div class="flex-1 flex flex-col">
            <header class="border-b border-gray-200 bg-white">
                <div class="px-6 py-4 flex items-center justify-between">
                    <div class="flex items-center space-x-3">
                        <button id="sidebar-toggle" class="md:hidden p-2 text-gray-500 hover:text-gray-700">
                            <i class="fas fa-bars"></i>
                        </button>
                        <h1 class="text-2xl font-bold text-gray-900">
                            @if(request()->is('dashboard'))
                                Dashboard
                            @elseif(request()->is('farmers*'))
                                Farmers
                            @elseif(request()->is('paddy-purchases*'))
                                Paddy Purchases
                            @elseif(request()->is('milling-batches*'))
                                Milling Batches
                            @elseif(request()->is('inventory*'))
                                Inventory
                            @elseif(request()->is('sales*'))
                                Sales
                            @elseif(request()->is('reports*'))
                                Reports
                            @elseif(request()->is('profile*'))
                                Profile
                            @elseif(request()->is('auth*'))
                                @if(request()->is('login'))
                                    Login
                                @elseif(request()->is('register'))
                                    Register
                                @elseif(request()->is('forgot-password'))
                                    Forgot Password
                                @elseif(request()->is('reset-password'))
                                    Reset Password
                                @elseif(request()->is('verify-email'))
                                    Verify Email
                                @elseif(request()->is('confirm-password'))
                                    Confirm Password
                                @else
                                    Auth
                                @endif
                            @else
                                Dashboard
                            @endif
                        </h1>
                    </div>
                    <div class="flex items-center space-x-3">
                        <div class="relative">
                            <input type="text" placeholder="Search..." class="px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500">
                            <i class="fas fa-search absolute inset-y-0 right-3 my-auto text-gray-400"></i>
                        </div>
                        <div class="relative">
                            <button class="p-2 text-gray-500 hover:text-gray-700 relative">
                                <i class="fas fa-bell"></i>
                                <span class="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                            </button>
                            @auth
                                <div class="w-10 h-10 bg-green-200 rounded-xl flex items-center justify-center">
                                    {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
                                </div>
                            @endauth
                        </div>
                    </div>
                </div>
            </header>

            <main class="flex-1 p-6 overflow-y-auto">
                @if(request()->is('dashboard'))
                    {{-- Welcome Section --}}
                    <div class="mb-8">
                        <div class="flex items-center justify-between mb-4">
                            <h2 class="text-xl font-bold text-gray-900">Welcome back, {{ explode(' ', Auth::user()->name)[0] }}!</h2>
                            <span class="px-3 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                                Good {{ now()->hour < 12 ? 'morning' : (now()->hour < 17 ? 'afternoon' : 'evening') }}
                            </span>
                        </div>
                        <p class="text-gray-600">
                            Here's what's happening at your mill today — {{ now()->format('l, F j, Y') }}
                        </p>
                    </div>

                    {{-- Stats Cards --}}
                    <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                        <!-- Farmers -->
                        <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow hover:-translate-y-1">
                            <div class="flex items-center mb-4">
                                <div class="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                                    <i class="fas fa-user-tie text-green-600"></i>
                                </div>
                                <h3 class="ml-4 text-lg font-semibold text-gray-800">Total Farmers</h3>
                            </div>
                            <p class="text-3xl font-bold text-green-600">{{ $stats['farmers'] }}</p>
                            <p class="text-sm text-green-600">↑ Active this month</p>
                        </div>

                        <!-- Purchases -->
                        <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow hover:-translate-y-1">
                            <div class="flex items-center mb-4">
                                <div class="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                                    <i class="fas fa-shopping-cart text-green-600"></i>
                                </div>
                                <h3 class="ml-4 text-lg font-semibold text-gray-800">Paddy Purchased</h3>
                            </div>
                            <p class="text-3xl font-bold text-green-600">{{ $stats['purchases'] }} tons</p>
                            <p class="text-sm text-green-600">↑ 12% from last month</p>
                        </div>

                        <!-- Inventory -->
                        <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow hover:-translate-y-1">
                            <div class="flex items-center mb-4">
                                <div class="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                                    <i class="fas fa-boxes text-green-600"></i>
                                </div>
                                <h3 class="ml-4 text-lg font-semibold text-gray-800">Current Inventory</h3>
                            </div>
                            <p class="text-3xl font-bold text-green-600">{{ $stats['milling'] }} batches</p>
                            <p class="text-sm text-green-600">↑ 8% from last month</p>
                        </div>

                        <!-- Sales -->
                        <div class="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow hover:-translate-y-1">
                            <div class="flex items-center mb-4">
                                <div class="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                                    <i class="fas fa-dollar-sign text-green-600"></i>
                                </div>
                                <h3 class="ml-4 text-lg font-semibold text-gray-800">Monthly Sales</h3>
                            </div>
                            <p class="text-3xl font-bold text-green-600">${{ number_format($stats['sales_total'] ?? 0, 0) }}</p>
                            <p class="text-sm text-green-600">↑ 15% from last month</p>
                        </div>
                    </div>

                    <!-- Recent Activity -->
                    <div class="mt-8">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
                        <div class="space-y-4">
                            @foreach($recentActivities as $activity)
                                <div class="flex items-start space-x-4 p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow">
                                    <div class="w-10 h-10 flex-shrink-0 bg-green-50 rounded-xl flex items-center justify-center">
                                        <i class="{{ $activity->icon }} text-green-600"></i>
                                    </div>
                                    <div class="flex-1">
                                        <p class="font-medium text-gray-800">{{ $activity->title }}</p>
                                        <p class="text-sm text-gray-500">{{ $activity->description }}</p>
                                        <p class="text-xs text-green-600">{{ $activity->time }}</p>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif

                @if(request()->is('farmers*'))
                    {{-- Farmers Management --}}
                    <div class="mb-8">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">Farmer Management</h2>
                        @include('farmers.partials._table')
                    </div>
                @endif

                @if(request()->is('paddy-purchases*'))
                    {{-- Paddy Purchases --}}
                    <div class="mb-8">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">Paddy Purchases</h2>
                        @include('paddy-purchases.partials._table')
                    </div>
                @endif

                @if(request()->is('milling-batches*'))
                    {{-- Milling Batches --}}
                    <div class="mb-8">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">Milling Batches</h2>
                        @include('milling-batches.partials._table')
                    </div>
                @endif

                @if(request()->is('inventory*'))
                    {{-- Inventory --}}
                    <div class="mb-8">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">Inventory Management</h2>
                        @include('inventory.partials._table')
                    </div>
                @endif

                @if(request()->is('sales*'))
                    {{-- Sales --}}
                    <div class="mb-8">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">Sales Management</h2>
                        @include('sales.partials._table')
                    </div>
                @endif

                @if(request()->is('reports*'))
                    {{-- Reports --}}
                    <div class="mb-8">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">Reports & Analytics</h2>
                        @include('reports.partials._table')
                    </div>
                @endif
            </main>
        </div>
    </body>
</html>
This agent fell back to using the tool `bash`. Below is a transcript of the attempt.
Command: git show HEAD:resources/views/dashboard.blade.php
Description: Get original dashboard.blade.php from HEAD

Exit code: 128
Error: error: pathspec 'resources/views/dashboard.blade.php' did not match any file(s) known to git