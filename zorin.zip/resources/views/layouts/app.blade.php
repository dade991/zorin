<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Zorin Rice Milling')</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="antialiased bg-gray-50">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <aside class="hidden w-64 bg-rice-950 text-white flex-shrink-0">
            <div class="px-4 py-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-rice-600/20 rounded-xl flex items-center justify-center">
                        <i class="fas fa-seedling text-rice-400 text-xl"></i>
                    </div>
                    <span class="font-bold text-xl">Zorin</span>
                </div>
            </div>
            <nav class="mt-10 space-y-2 px-4">
                <a href="{{ route('dashboard') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('dashboard') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-home me-3"></i>
                    Dashboard
                </a>
                <a href="{{ route('farmers.index') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('farmers*') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-user-tie me-3"></i>
                    Farmers
                </a>
                <a href="{{ route('paddy-purchases.index') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('paddy-purchases*') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-shopping-cart me-3"></i>
                    Paddy Purchases
                </a>
                <a href="{{ route('milling-batches.index') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('milling-batches*') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-seedling me-3"></i>
                    Milling Batches
                </a>
                <a href="{{ route('inventory.index') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('inventory*') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-boxes me-3"></i>
                    Inventory
                </a>
                <a href="{{ route('sales.index') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('sales*') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-dollar-sign me-3"></i>
                    Sales
                </a>
                <a href="{{ route('reports.index') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('reports*') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-chart-bar me-3"></i>
                    Reports
                </a>
                <a href="{{ route('customers.index') }}" class="flex items-center px-3 py-2 rounded-md text-sm font-medium {{ request()->is('customers*') ? 'bg-rice-800' : 'text-rice-200 hover:bg-rice-800/50' }} transition-colors">
                    <i class="fas fa-users me-3"></i>
                    Customers
                </a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 w-full">
            <!-- Header -->
            <header class="bg-white border-b border-gray-200">
                <div class="flex items-center justify-between px-6 py-4">
                    <div class="flex items-center space-x-4">
                        @auth
                            <div class="w-8 h-8 bg-rice-600/20 rounded-full flex items-center justify-center text-rice-600">
                                {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
                            </div>
                        @else
                            <div class="w-8 h-8 bg-rice-600/20 rounded-full flex items-center justify-center text-rice-600">
                                ZR
                            </div>
                        @endauth
                        <div>
                            <h1 class="text-lg font-semibold text-gray-900">@yield('page-title', 'Dashboard')</h1>
                            <p class="text-sm text-gray-500">@yield('page-subtitle', '')</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        @auth
                            <a href="{{ route('profile.edit') }}" class="text-gray-500 hover:text-gray-700 transition-colors">
                                <i class="fas fa-user-circle text-xl"></i>
                            </a>
                            <form action="{{ route('logout') }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="text-gray-500 hover:text-gray-700 transition-colors p-1 rounded">
                                    <i class="fas fa-sign-out-alt text-xl"></i>
                                </button>
                            </form>
                        @else
                            <a href="{{ route('login') }}" class="px-3 py-1 rounded-md text-sm font-medium text-rice-600 border border-rice-200 hover:bg-rice-50 transition-colors">Sign In</a>
                            <a href="{{ route('register') }}" class="ml-2 px-3 py-1 rounded-md bg-rice-600 text-white text-sm font-medium hover:bg-rice-700 transition-colors">Get Started</a>
                        @endauth
                    </div>
                </div>
            </header>

            <!-- Page Content -->
            <div class="p-6">
                @yield('content')
            </div>
        </main>
    </div>
</body>
</html>