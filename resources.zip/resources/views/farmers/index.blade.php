@extends('layouts.app')

@section('title', 'Farmers - Zorin Rice Milling')

@section('content')
<div class="page-header">
    <h1 class="page-title">Farmers</h1>
    <p class="page-subtitle">Manage your farmer database and relationships</p>
    <a href="{{ route('farmers.create') }}" class="btn btn-primary">Add New Farmer</a>
</div>

@if (session('status'))
    <div class="alert alert-success">
        <i class="fas fa-check-circle mr-2"></i>
        {{ session('status') }}
    </div>
@endif

@if ($errors->any())
    <div class="alert alert-error">
        <i class="fas fa-exclamation-triangle mr-2"></i>
        <ul class="list-disc pl-5 mt-2 mb-0">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="card">
    <div class="card-header">
        <div class="card-title">Farmer List</div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="dash-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Village</th>
                        <th>State</th>
                        <th>ID Number</th>
                        <th>Purchases</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @if ($farmers->isEmpty())
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <p class="text-center text-text-light">No farmers found. Click "Add New Farmer" to get started.</p>
                            </td>
                        </tr>
                    @else
                        @foreach ($farmers as $farmer)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $farmer->name }}</td>
                            <td>{{ $farmer->phone }}</td>
                            <td>{{ $farmer->village }}</td>
                            <td>{{ $farmer->state }}</td>
                            <td>{{ $farmer->id_number }}</td>
                            <td>
                                <span class="badge badge-info">{{ $farmer->paddyPurchases()->count() }}</span>
                            </td>
                            <td>
                                <div class="flex gap-2">
                                    <a href="{{ route('farmers.show', $farmer) }}" class="btn btn-outline btn-sm">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('farmers.edit', $farmer) }}" class="btn btn-outline btn-sm">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('farmers.destroy', $farmer) }}" method="POST" class="inline-block">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-outline btn-sm" onclick="return confirm('Are you sure you want to delete this farmer?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>

{{ $farmers->links() }}
@endsection