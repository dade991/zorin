<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Zorin Rice Milling</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="antialiased">
    <!-- Page Container -->
    <div class="min-h-screen bg-black">

        <!-- Navigation -->
        <nav class="fixed inset-x-0 top-0 z-50 flex h-16 items-center justify-between px-6 lg:px-12 backdrop-blur-sm bg-black/50">
            <div class="flex items-center">
                <!-- Logo -->
                <button class="flex items-center w-10 h-10 bg-green-600/20 rounded-xl hover:bg-green-600/30 transition-colors">
                    <i class="fas fa-seedling text-green-400 text-xl"></i>
                </button>
                <span class="ms-3 font-bold text-white text-lg">Zorin</span>
            </div>

            <!-- Nav Links -->
            <div class="hidden md:flex space-x-8">
                <a href="{{ route('home') }}" class="text-white/70 hover:text-white transition-colors font-medium">Home</a>
                <a href="#about" class="text-white/70 hover:text-white transition-colors font-medium">About</a>
                <a href="#features" class="text-white/70 hover:text-white transition-colors font-medium">Features</a>
                <a href="#testimonials" class="text-white/70 hover:text-white transition-colors font-medium">Testimonials</a>
                <a href="#contact" class="text-white/70 hover:text-white transition-colors font-medium">Contact</a>
            </div>

            <!-- Auth Buttons -->
            <div class="flex items-center space-x-3">
                @auth
                    <div class="w-10 h-10 bg-green-600/20 rounded-xl flex items-center justify-center hover:bg-green-600/30 transition-colors">
                        {{ strtoupper(substr(Auth::user()->name, 0, 1)) }}
                    </div>
                @else
                    <a href="{{ route('login') }}" class="px-4 py-2 rounded-full border border-white/20 text-white/80 hover:text-white hover:border-white/30 transition-colors">Sign In</a>
                    <a href="{{ route('register') }}" class="px-5 py-2 rounded-full bg-white/10 text-white/90 hover:bg-white/20 transition-colors">Get Started</a>
                @endauth
            </div>
        </nav>

        <!-- Hero Section -->
        <section class="relative h-[calc(100vh-4.5rem)] overflow-hidden">
            <!-- Dark Gradient Overlay + Rice Terrace Pattern Simulation -->
            <div class="absolute inset-0 bg-gradient-to-b from-black via-black/90 to-black backdrop-blur">
                <!-- Rice Terrace Pattern Simulation -->
                <div class="absolute inset-0 bg-[radial-gradient(var(--color-primary-200)_1px,transparent_1px)] bg-[size:24px_24px] opacity-[0.15]"></div>
            </div>

            <!-- Terraced Field Shape -->
            <div class="absolute inset-0 pointer-events-none">
                <div class="absolute bottom-0 left-0 w-full h-[300px] bg-gradient-to-t from-black/80 to-transparent"></div>
            </div>

            <!-- Hero Content -->
            <div class="relative flex h-full items-center justify-center px-6 lg:px-12 text-center z-20">
                <div class="max-w-4xl space-y-8">
                    <!-- Brand Logo -->
                    <div class="flex items-center justify-center space-x-4 mb-6">
                        <div class="w-16 h-16 bg-gradient-to-bl from-green-600 to-emerald-700 rounded-2xl flex items-center justify-center drop-shadow-lg">
                            <i class="fas fa-seedling text-white text-3xl"></i>
                        </div>
                        <div class="text-left">
                            <h2 class="text-3xl font-bold text-white tracking-tighter">Zorin Rice Milling</h2>
                            <p class="text-white/60 font-medium">Premium Agricultural Management</p>
                        </div>
                    </div>

                    <!-- Main Headline -->
                    <h1 class="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
                        Premium Quality Rice, Milled with Precision
                    </h1>

                    <!-- Subheadline -->
                    <p class="text-xl md:text-2xl text-white/70 max-w-2xl mb-10">
                        Experience the future of rice mill management with our comprehensive platform that optimizes every stage from purchase to sale.
                    </p>

                    <!-- CTA Button -->
                    <div class="flex justify-center">
                        <a href="{{ route('dashboard') }}"
                           class="flex items-center px-8 py-4 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 hover:border-white/30 transition-all duration-300 text-white/90 hover:text-white font-medium text-lg">
                            Get Started Today
                            <i class="fas fa-arrow-right ml-3 transition-transform duration-300 hover:translate-x-1"></i>
                        </a>
                    </div>

                    <!-- Floating Stat Cards -->
                    <div class="absolute bottom-[calc(50%-100px)] left-1/2 -translate-x-1/2 flex space-x-6">
                        <!-- Stat Card 1 -->
                        <div class="flex items-center space-x-4 bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6 hover:bg-white/10 hover:border-white/20 transition-all duration-300 transform hover:-translate-y-2">
                            <div class="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center text-white/90">
                                <i class="fas fa-users text-xl"></i>
                            </div>
                            <div class="space-y-1">
                                <p class="text-white/80 font-bold text-2xl">1M+</p>
                                <p class="text-white/50 text-sm uppercase tracking-wide">Farmers Served</p>
                            </div>
                        </div>

                        <!-- Stat Card 2 -->
                        <div class="flex items-center space-x-4 bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6 hover:bg-white/10 hover:border-white/20 transition-all duration-300 transform hover:-translate-y-2">
                            <div class="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center text-white/90">
                                <i class="fas fa-tachometer-alt text-xl"></i>
                            </div>
                            <div class="space-y-1">
                                <p class="text-white/80 font-bold text-2xl">4.9</p>
                                <p class="text-white/50 text-sm uppercase tracking-wide">Avg. Rating</p>
                            </div>
                        </div>

                        <!-- Stat Card 3 -->
                        <div class="flex items-center space-x-4 bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6 hover:bg-white/10 hover:border-white/20 transition-all duration-300 transform hover:-translate-y-2">
                            <div class="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center text-white/90">
                                <i class="fas fa-chart-line text-xl"></i>
                            </div>
                            <div class="space-y-1">
                                <p class="text-white/80 font-bold text-2xl">20+</p>
                                <p class="text-white/50 text-sm uppercase tracking-wide">Mill Locations</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Animated Particle Layer -->
            <div class="absolute inset-0 pointer-none">
                <div class="absolute inset-0 bg-[radial-gradient(var(--color-primary-200)_1px,transparent_1px)] bg-[size:40px_40px] opacity-[0.05] animate-[move_20s_linear_infinite]"></div>
            </div>
        </section>

        <!-- Features Section -->
        <section id="features" class="relative py-24 bg-gray-900/50">
            <div class="max-w-7xl mx-auto px-6 lg:px-12">
                <div class="text-center mb-16">
                    <h2 class="text-4xl font-bold text-white mb-6">Why Choose Zorin?</h2>
                    <p class="text-white/60 max-w-3xl mx-auto">
                        Our platform combines cutting-edge technology with deep agricultural expertise to deliver unparalleled efficiency and insight.
                    </p>
                </div>

                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <!-- Farmer Management -->
                    <div class="flex flex-col items-center bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                        <div class="w-14 h-14 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-user-tie text-green-400 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-4">Farmer Management</h3>
                        <p class="text-white/50">
                            Maintain detailed farmer databases, track purchases, and build strong relationships through our intuitive interface.
                        </p>
                    </div>

                    <!-- Purchase Tracking -->
                    <div class="flex flex-col items-center bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                        <div class="w-14 h-14 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-shopping-cart text-green-400 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-4">Purchase Tracking</h3>
                        <p class="text-white/50">
                            Record paddy purchases with automatic calculations for totals and farmer credits in real-time.
                        </p>
                    </div>

                    <!-- Milling Operations -->
                    <div class="flex flex-col items-center bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                        <div class="w-14 h-14 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-seedling text-green-400 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-4">Milling Operations</h3>
                        <p class="text-white/50">
                            Log milling batches, track efficiency, and monitor output quality with precision analytics.
                        </p>
                    </div>

                    <!-- Inventory Control -->
                    <div class="flex flex-col items-center bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                        <div class="w-14 h-14 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-boxes text-green-400 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-4">Inventory Control</h3>
                        <p class="text-white/50">
                            Monitor stock levels, set smart alerts, and manage multiple rice varieties effortlessly.
                        </p>
                    </div>

                    <!-- Sales Management -->
                    <div class="flex flex-col items-center bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                        <div class="w-14 h-14 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-dollar-sign text-green-400 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-4">Sales Management</h3>
                        <p class="text-white/50">
                            Create invoices, track payments, manage customer relationships, and analyze sales trends.
                        </p>
                    </div>

                    <!-- Reports & Analytics -->
                    <div class="flex flex-col items-center bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-8 text-center hover:bg-white/10 hover:border-white/20 transition-all duration-300">
                        <div class="w-14 h-14 bg-gradient-to-br from-green-600/20 to-emerald-600/20 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-chart-bar text-green-400 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-white mb-4">Reports & Analytics</h3>
                        <p class="text-white/50">
                            Generate detailed reports on purchases, sales, milling efficiency, and profitability for data-driven decisions.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <!-- Call to Action Section -->
        <section class="relative py-24 bg-gradient-to-b from-green-950 to-black/80">
            <div class="max-w-4xl mx-auto px-6 lg:px-12 text-center">
                <h2 class="text-4xl font-bold text-white mb-6">Ready to Transform Your Rice Mill Operations?</h2>
                <p class="text-white/60 mb-10 max-w-2xl mx-auto">
                    Join thousands of successful rice millers who have optimized their operations with our comprehensive platform.
                </p>
                <div class="space-x-4">
                    <a href="{{ route('login') }}"
                       class="flex items-center px-8 py-4 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 hover:border-white/30 transition-all duration-300 text-white/90 hover:text-white font-medium">
                        Login to Your Account
                        <i class="fas fa-sign-in-alt ml-3 transition-transform duration-300 hover:translate-x-1"></i>
                    </a>
                    <a href="{{ route('register') }}"
                       class="flex items-center px-8 py-4 rounded-full bg-white/20 text-white/90 hover:bg-white/30 transition-all duration-300 font-medium">
                        Create Free Account
                        <i class="fas fa-user-plus ml-3 transition-transform duration-300 hover:translate-x-1"></i>
                    </a>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer class="relative py-12 bg-black/80 border-t border-white/10">
            <div class="max-w-7xl mx-auto px-6 lg:px-12 flex flex-col items-center gap-6 text-center">
                <div class="flex items-center justify-center space-x-4">
                    <div class="w-10 h-10 bg-gradient-to-bl from-green-600 to-emerald-700 rounded-xl flex items-center justify-center">
                        <i class="fas fa-seedling text-white"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-white">Zorin Rice Milling</h3>
                        <p class="text-white/50 text-sm">Empowering rice millers with technology</p>
                    </div>
                </div>
                <div class="flex flex-col items-center space-x-4 space-y-4 md:flex-row md:space-x-8 md:space-y-0">
                    <a href="#" class="text-white/60 hover:text-white transition-colors">Privacy Policy</a>
                    <a href="#" class="text-white/60 hover:text-white transition-colors">Terms of Service</a>
                    <a href="#" class="text-white/60 hover:text-white transition-colors">Security</a>
                    <a href="#" class="text-white/60 hover:text-white transition-colors">Support</a>
                </div>
                <p class="text-white/40 text-sm">
                    © {{ date('Y') }} Zorin Rice Milling. All rights reserved.
                </p>
            </div>
        </footer>
    </div>

    <!-- Alpine.js for mobile menu (if needed) -->
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('mobileMenu', () => ({
                open: false,
                toggle() {
                    this.open = !this.open;
                }
            }));
        });
    </script>
</body>
</html>